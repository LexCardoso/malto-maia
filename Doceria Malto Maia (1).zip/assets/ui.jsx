/* ============================================================
   MALTO MAIA — UI base (context, logo, header, footer, icons)
   ============================================================ */
const { createContext, useContext, useState, useEffect, useRef, useMemo } = React;

window.WA_NUMBER = '5521999999999';

/* ---------- App context ---------- */
const AppContext = createContext(null);
window.AppContext = AppContext;
window.useApp = () => useContext(AppContext);

/* ---------- helpers ---------- */
window.fmtBRL = (n) =>
  n == null ? null : 'R$ ' + n.toFixed(2).replace('.', ',');

window.cx = (...a) => a.filter(Boolean).join(' ');

/* ============================================================
   ICONS
   ============================================================ */
const Ic = {
  menu:  (p) => <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" {...p}><path d="M3 6h18M3 12h18M3 18h18"/></svg>,
  close: (p) => <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" {...p}><path d="M6 6l12 12M18 6L6 18"/></svg>,
  wa:    (p) => <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" {...p}><path d="M.05 24l1.7-6.2A11.86 11.86 0 0 1 .16 11.9C.16 5.34 5.5 0 12.06 0a11.8 11.8 0 0 1 8.4 3.49 11.8 11.8 0 0 1 3.48 8.41c0 6.56-5.34 11.9-11.9 11.9a11.9 11.9 0 0 1-5.69-1.45L.05 24zM6.6 20.1c1.68 1 3.28 1.6 5.4 1.6 5.45 0 9.9-4.43 9.9-9.88A9.86 9.86 0 0 0 12.06 2C6.6 2 2.17 6.43 2.17 11.9c0 2.23.65 3.9 1.75 5.65l-1 3.66 3.68-1.1zM17.9 14.7c-.07-.12-.27-.2-.56-.34-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.22-.64.07a8.1 8.1 0 0 1-2.38-1.47 9 9 0 0 1-1.65-2.05c-.17-.3 0-.46.13-.6.13-.14.3-.35.45-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.6-.92-2.2-.24-.58-.49-.5-.67-.5l-.57-.02c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.9 1.22 3.1.15.2 2.1 3.2 5.1 4.49.71.3 1.27.49 1.7.63.72.23 1.37.2 1.88.12.58-.08 1.76-.72 2-1.42.25-.7.25-1.28.18-1.4z"/></svg>,
  ig:    (p) => <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.9" {...p}><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1.1" fill="currentColor" stroke="none"/></svg>,
  pin:   (p) => <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.9" {...p}><path d="M20 10c0 5.4-8 12-8 12s-8-6.6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="2.6"/></svg>,
  clock: (p) => <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.9" {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>,
  arrow: (p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 12h14M13 6l6 6-6 6"/></svg>,
  plus:  (p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" {...p}><path d="M12 5v14M5 12h14"/></svg>,
  minus: (p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" {...p}><path d="M5 12h14"/></svg>,
  search:(p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>,
  check: (p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 13l4 4L19 7"/></svg>,
  edit:  (p) => <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>,
  trash: (p) => <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>,
  pdf:   (p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 15h2.2a1.3 1.3 0 0 0 0-2.6H8V18"/></svg>,
  qr:    (p) => <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.9" {...p}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M21 14v0M17 21h4v-4M14 21h0" strokeLinecap="round"/></svg>,
  star:  (p) => <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" {...p}><path d="M12 2l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.8 6.1 20.8l1.2-6.6L2.5 9l6.6-.9z"/></svg>,
  globe: (p) => <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.9" {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 2.5 15.4 0 18M12 3c-2.5 2.6-2.5 15.4 0 18"/></svg>,
  cart:  (p) => <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M2 3h2.2l2 12.5a1.6 1.6 0 0 0 1.6 1.3h9.4a1.6 1.6 0 0 0 1.6-1.3L20 7H5.2"/></svg>,
};
window.Ic = Ic;

/* ============================================================
   LOGO  (placeholder no espírito da marca — casa + coqueiro
   recortados em preto sobre sol amarelo)
   ============================================================ */
function LogoMark({ size = 56, onDark = false }) {
  const img = <img src="assets/logo-mark.png" alt="" aria-hidden="true"
    style={{ height: size, width: 'auto', display: 'block' }} />;
  if (!onDark) return img;
  // dark backgrounds: the silhouette is near-black, so seat it on a light disc
  return (
    <span style={{ width: size * 1.18, height: size * 1.18, borderRadius: '50%', background: 'var(--cream)', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto' }}>
      <img src="assets/logo-mark.png" alt="" aria-hidden="true" style={{ height: size * 0.82, width: 'auto', display: 'block' }} />
    </span>
  );
}
window.LogoMark = LogoMark;

function Logo({ size = 52, onDark = false, onClick }) {
  const ink = onDark ? 'var(--cream)' : 'var(--espresso-ink)';
  const sub = onDark ? 'rgba(247,241,230,0.7)' : 'var(--muted)';
  return (
    <button onClick={onClick} aria-label="Malto Maia — início"
      style={{ display: 'flex', alignItems: 'center', gap: 13, background: 'none', border: 0, padding: 0, cursor: onClick ? 'pointer' : 'default', textAlign: 'left' }}>
      <LogoMark size={size} onDark={onDark} />
      <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <span style={{ fontFamily: 'var(--body)', fontWeight: 800, fontSize: size * 0.19, letterSpacing: '0.34em', color: sub, marginBottom: 4, whiteSpace: 'nowrap' }}>DOCERIA</span>
        <span style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: size * 0.42, lineHeight: 1, letterSpacing: '0.01em', color: ink, whiteSpace: 'nowrap' }}>Malto Maia</span>
        <span style={{ fontFamily: 'var(--body)', fontWeight: 700, fontSize: size * 0.155, letterSpacing: '0.16em', color: 'var(--terracota)', marginTop: 5, whiteSpace: 'nowrap' }}>PRAIA SECA · RJ</span>
      </span>
    </button>
  );
}
window.Logo = Logo;

/* ============================================================
   LANGUAGE TOGGLE
   ============================================================ */
function LangToggle({ onDark = false }) {
  const { lang, setLang } = useApp();
  const base = {
    display: 'inline-flex', alignItems: 'center', borderRadius: 999,
    border: '1.5px solid ' + (onDark ? 'rgba(247,241,230,0.35)' : 'var(--line-strong)'),
    overflow: 'hidden', background: onDark ? 'rgba(0,0,0,0.15)' : 'var(--cream-soft)',
  };
  const seg = (code) => ({
    padding: '7px 13px', fontWeight: 800, fontSize: 13, letterSpacing: '0.04em',
    background: lang === code ? 'var(--sun)' : 'transparent',
    color: lang === code ? 'var(--espresso-ink)' : (onDark ? 'var(--cream)' : 'var(--muted)'),
    border: 0, cursor: 'pointer', transition: 'background .15s',
  });
  return (
    <div style={base} role="group" aria-label="Idioma / Language">
      <button style={seg('pt')} onClick={() => setLang('pt')} aria-pressed={lang === 'pt'}>PT</button>
      <button style={seg('en')} onClick={() => setLang('en')} aria-pressed={lang === 'en'}>EN</button>
    </div>
  );
}
window.LangToggle = LangToggle;

/* ============================================================
   HEADER
   ============================================================ */
function Header() {
  const { t, route, go, cart } = useApp();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => { setOpen(false); }, [route]);

  const links = [
    { id: 'home', label: t('nav.home') },
    { id: 'menu', label: t('nav.menu') },
    { id: 'order', label: t('nav.order') },
    { id: 'admin', label: t('nav.admin') },
  ];

  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50,
      background: scrolled ? 'rgba(247,241,230,0.92)' : 'rgba(247,241,230,0.6)',
      backdropFilter: 'blur(12px)',
      borderBottom: '1px solid ' + (scrolled ? 'var(--line)' : 'transparent'),
      transition: 'background .25s, border-color .25s',
    }}>
      <div className="wrap" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 78, gap: 16 }}>
        <Logo size={46} onClick={() => go('home')} />

        <nav className="hdr-nav" style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {links.map((l) => (
            <button key={l.id} onClick={() => go(l.id)}
              style={{
                background: 'none', border: 0, padding: '9px 14px', borderRadius: 999,
                fontFamily: 'var(--body)', fontWeight: 700, fontSize: 15.5,
                color: route === l.id ? 'var(--espresso-ink)' : 'var(--muted)',
                position: 'relative', cursor: 'pointer',
              }}>
              {l.label}
              {route === l.id && <span style={{ position: 'absolute', left: 14, right: 14, bottom: 3, height: 2.5, background: 'var(--sun)', borderRadius: 2 }} />}
            </button>
          ))}
        </nav>

        <div className="row" style={{ gap: 10 }}>
          <div className="hdr-lang"><LangToggle /></div>
          <button className="btn btn-primary btn-sm hdr-order-btn" onClick={() => go('order')} style={{ position: 'relative' }}>
            <Ic.cart />
            <span className="hdr-order-label">{t('nav.order')}</span>
            {cartCount > 0 && (
              <span style={{ position: 'absolute', top: -6, right: -6, minWidth: 20, height: 20, padding: '0 5px', borderRadius: 999, background: 'var(--terracota)', color: '#fff', fontSize: 12, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{cartCount}</span>
            )}
          </button>
          <button className="hdr-burger" onClick={() => setOpen((o) => !o)} aria-label="Menu"
            style={{ display: 'none', background: 'var(--cream-soft)', border: '1.5px solid var(--line-strong)', borderRadius: 12, width: 46, height: 46, alignItems: 'center', justifyContent: 'center', color: 'var(--espresso)' }}>
            {open ? <Ic.close /> : <Ic.menu />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="hdr-drawer" style={{ borderTop: '1px solid var(--line)', background: 'var(--cream-soft)' }}>
          <div className="wrap" style={{ paddingTop: 14, paddingBottom: 20, display: 'flex', flexDirection: 'column', gap: 4 }}>
            {links.map((l) => (
              <button key={l.id} onClick={() => go(l.id)}
                style={{ textAlign: 'left', background: route === l.id ? 'var(--cream-deep)' : 'none', border: 0, padding: '14px 16px', borderRadius: 12, fontFamily: 'var(--display)', fontWeight: 600, fontSize: 22, color: 'var(--espresso-ink)' }}>
                {l.label}
              </button>
            ))}
            <div style={{ marginTop: 12 }}><LangToggle /></div>
          </div>
        </div>
      )}
    </header>
  );
}
window.Header = Header;

/* ============================================================
   FOOTER
   ============================================================ */
function Footer() {
  const { t, go } = useApp();
  const wa = `https://wa.me/${WA_NUMBER}`;
  const col = { display: 'flex', flexDirection: 'column', gap: 12 };
  const head = { fontFamily: 'var(--body)', fontWeight: 800, fontSize: 13, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--sun)', marginBottom: 4 };
  const lnk = { background: 'none', border: 0, padding: 0, textAlign: 'left', color: 'rgba(247,241,230,0.82)', fontSize: 15.5, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--body)' };
  return (
    <footer style={{ background: 'var(--espresso-ink)', color: 'var(--cream)', marginTop: 'auto' }}>
      <div className="wrap section-tight" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 40, alignItems: 'start' }}>
        <div style={{ ...col, gap: 16, maxWidth: 320 }}>
          <Logo size={46} onDark onClick={() => go('home')} />
          <p style={{ color: 'rgba(247,241,230,0.7)', fontSize: 15, lineHeight: 1.6 }}>{t('foot.tagline')}</p>
          <div className="row" style={{ gap: 10 }}>
            <a href={wa} target="_blank" rel="noopener" className="btn btn-wa btn-sm" style={{ gap: 8 }}><Ic.wa /> WhatsApp</a>
            <a href="https://instagram.com" target="_blank" rel="noopener" aria-label="Instagram"
              style={{ width: 44, height: 44, borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1.5px solid rgba(247,241,230,0.3)', color: 'var(--cream)' }}><Ic.ig /></a>
          </div>
        </div>
        <div style={col}>
          <div style={head}>{t('foot.explore')}</div>
          <button style={lnk} onClick={() => go('home')}>{t('nav.home')}</button>
          <button style={lnk} onClick={() => go('menu')}>{t('nav.menu')}</button>
          <button style={lnk} onClick={() => go('order')}>{t('nav.order')}</button>
          <button style={lnk} onClick={() => go('admin')}>{t('nav.admin')}</button>
        </div>
        <div style={col}>
          <div style={head}>{t('foot.hours')}</div>
          <p style={{ color: 'rgba(247,241,230,0.82)', fontSize: 15.5 }}>{t('visit.hours')}</p>
          <div style={{ ...head, marginTop: 14 }}>{t('foot.contact')}</div>
          <p style={{ color: 'rgba(247,241,230,0.82)', fontSize: 15.5 }}>{t('visit.addr')}</p>
        </div>
      </div>
      <div style={{ borderTop: '1px solid rgba(247,241,230,0.14)' }}>
        <div className="wrap" style={{ paddingTop: 18, paddingBottom: 18, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10, color: 'rgba(247,241,230,0.55)', fontSize: 13.5 }}>
          <span>© 2026 Malto Maia · Praia Seca – RJ</span>
          <span style={{ fontFamily: 'var(--script)', fontSize: 19, color: 'var(--sun-soft)' }}>{t('foot.rights')}</span>
        </div>
      </div>
    </footer>
  );
}
window.Footer = Footer;

/* ---------- Section heading ---------- */
function SectionHead({ eyebrow, title, sub, center, kicker }) {
  return (
    <div style={{ maxWidth: center ? 720 : 620, margin: center ? '0 auto' : 0, textAlign: center ? 'center' : 'left' }}>
      {eyebrow && <div className="eyebrow" style={{ marginBottom: 8 }}>{eyebrow}</div>}
      {kicker && <div className="eyebrow-tag" style={{ marginBottom: 10 }}>{kicker}</div>}
      <h2 className="h-1">{title}</h2>
      {sub && <p className="lead" style={{ marginTop: 16 }}>{sub}</p>}
    </div>
  );
}
window.SectionHead = SectionHead;

Object.assign(window, { Logo, LogoMark, LangToggle, Header, Footer, SectionHead, Ic });
