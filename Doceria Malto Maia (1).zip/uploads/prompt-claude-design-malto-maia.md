# Prompt para o Claude Design — Site Doceria & Cafeteria Malto Maia

> Copie tudo abaixo e cole no Claude Design.

---

Você é um designer de produto sênior. Quero que você projete o **design visual completo e responsivo (mobile-first)** de um site para a **Doceria & Cafeteria Malto Maia**, um café de charme em Praia Seca, Araruama – RJ. O site será implementado depois em Django, então foque no **design de interface, layout, componentes e look & feel** — não em backend.

## Sobre o estabelecimento (use para o tom)
A Malto Maia é uma cafeteria intimista e rústica à beira-mar, com culinária de inspiração mineira. Funciona numa casa colonial amarela de telha de barro, com jardim, móveis de madeira patinada coloridos, pratos de cerâmica decorando as paredes, lousa com letra à mão e prensa francesa. O dono preza por um "conceito": ambiente cuidado, público maduro e apreciador de bom café, código de vestimenta (não se entra de traje de banho ou sem camisa). Nota 4,4/5 no TripAdvisor (Nº 15 de 91 em Araruama). Destaques recorrentes nas avaliações: o **espresso**, a **torta de coco** e o ambiente aconchegante.

**Importante:** NÃO faça uma vibe "praia/balada casual e colorida". O tom certo é **rústico-aconchegante com elegância artesanal**: caseiro e quente, mas curado e sofisticado.

## Identidade visual
- **Logo:** casa de praia + coqueiro recortados em preto sobre um sol amarelo; abaixo, "DOCERIA" em serifada elegante e "MALTO MAIA — Praia Seca – RJ". Reserve espaço de destaque para o logo no header e no hero. (Vou fornecer o arquivo do logo.)
- **Paleta** (extraída do próprio lugar):
  - Base: creme / off-white `#F7F1E6` (calor de papel, muito respiro)
  - Texto/profundidade: marrom-café / espresso `#3B2A20`
  - Acento quente secundário: terracota `#C0623B` (a telha)
  - **Cor de assinatura (CTAs, destaques): amarelo-sol `#F5A623`**
  - Acento natural sutil: verde-folha `#5E6B4F`
- **Tipografia:**
  - Títulos/display: serifada elegante (ex.: Playfair Display ou Cormorant) ecoando o logo
  - Corpo: sans humanista e quente (ex.: Inter ou Nunito Sans), bem legível
  - Acento manuscrito/script com MUITA parcimônia (lembrança da lousa), só em detalhes
- **Fotografia é protagonista:** imagens grandes e quentes de cafés, tortas, pães de queijo e do ambiente. Use placeholders fotográficos nesse espírito.

## Princípios de design
- **Mobile-first e totalmente responsivo** (a maioria dos acessos é por celular). Projete primeiro o mobile e depois o desktop.
- **Acessível ao público maduro:** bom contraste, tipografia generosa, toques/botões grandes.
- **Bilíngue PT-BR / EN:** inclua um seletor de idioma claro no header (PT | EN). Todos os textos de interface devem ter as duas versões. Nomes de pratos podem ficar em português com descrição/subtítulo em inglês quando fizer sentido.
- Layout limpo e respirável; os toques artesanais (textura de papel, detalhe de lousa) entram como tempero, nunca como poluição.

## Telas a projetar (4)

### 1. Landing page
Seções, nesta ordem aproximada:
1. **Header** fixo com logo, navegação e seletor PT/EN.
2. **Hero:** foto marcante (ex.: o cappuccino com o sol desenhado na espuma) + frase de impacto + botões "Ver cardápio" e "Fazer encomenda".
3. **Sobre o lugar:** história/ambiente, a alma mineira à beira-mar.
4. **Destaques do cardápio (carros-chefe):** cards com Espresso, Torta de coco, Cappuccino Mineiro e Pão de queijo.
5. **Galeria de fotos** do ambiente e dos pratos.
6. **Encomendas:** chamada com botão de WhatsApp.
7. **Avaliações/depoimentos** (estilo TripAdvisor/Google; nota 4,4★).
8. **Seção Instagram/Redes** (galeria representativa do feed — o embed real será resolvido depois).
9. **Localização + mapa** (Estrada de Praia Seca, Araruama – RJ) com botão "Como chegar".
10. **Horário de funcionamento** (9h–18h, todos os dias).
11. **"Nosso conceito"** — um bloco curto e elegante apresentando, de forma acolhedora (não como lista de proibições), o cuidado da casa com o ambiente.
12. **Footer** com redes sociais, contato e WhatsApp.

### 2. Página de Cardápio
- Cardápio completo, organizado por categorias (lista real abaixo), com navegação rápida entre categorias.
- Cada item: nome, descrição curta, preço; indicação visual de "indisponível" quando for o caso.
- **Data da última atualização** visível no topo.
- Botões: **"Exportar PDF"** (para impressão) e **"QR Code do cardápio"** (gera/exibe um QR que leva ao cardápio online).

### 3. Tela de Encomenda
- Cliente seleciona itens e quantidades (carrinho simples).
- Campo de observações.
- Botão final **"Enviar pedido no WhatsApp"** que abre o WhatsApp com a mensagem já montada (formato `wa.me/55XXXXXXXXXXX?text=...`). Use o número placeholder **`5521999999999`** por enquanto.
- Mostre claramente o resumo do pedido antes de enviar.

### 4. Painel administrativo (backend)
Interface limpa e simples para o dono gerenciar o cardápio (ele não é técnico):
- Listar, adicionar e editar itens (nome, categoria, descrição, preço).
- **Marcar item como disponível/indisponível** (toggle).
- Atualizar preço com facilidade.
- Exibir/atualizar a **data da última atualização**.
- Ações para **exportar o cardápio em PDF** e **gerar QR Code**.
- Visual administrativo sóbrio, mas coerente com a marca.

## Conteúdo real (cardápio)
Use os itens abaixo. Onde o preço está como "a definir", deixe um placeholder claro.

**☕ Bebidas Quentes**
- Café Espresso (70ml) — R$ 6,80
- Café Curto (30ml) — R$ 6,80
- Café Ristretto (15ml) — R$ 6,80
- Café Carioca (50ml água + 70ml café) — R$ 6,80
- Café Aromatizado (70ml, consultar sabores) — R$ 10,80
- Café Duplo (120ml) — R$ 10,80
- Macchiato (70ml café + 180ml leite vaporizado) — R$ 10,80
- Café Latte (70ml café + 180ml leite) — R$ 10,80
- Café Bombom (espresso, leite condensado, leite vaporizado, chantilly) — R$ 10,80
- Cappuccino Mineiro (leite, café, chocolate e canela, 250ml) — R$ 10,80
- Chocolate Suíço (leite vaporizado + chocolate cremoso, 250ml) — R$ 12,80
- Massala Chai (leite vaporizado + chá indiano, 250ml) — R$ 12,80
- Chá Prensa Francesa — R$ 10,80
- Moccacino (chocolate ou caramelo) — R$ 14,80
- Spirit of Lion (Amarula, espresso, chantilly) — R$ 22,80
- Irish Coffee (whisky, espresso, chantilly) — R$ 25,80
- Moccinha (leite condensado, espresso, conhaque, chantilly) — R$ 20,80

**🍨 Bebidas Geladas**
- Frappuccino (250ml) — R$ 17,50
- Affogato (sorvete, espresso, chantilly) — R$ 16,80
- Soda Italiana (200ml, consultar sabores) — R$ 12,00
- Milk Shake (350ml, consultar sabores) — R$ 18,50
- Banana Split — R$ 17,50
- Cappuccino Shake (350ml) — R$ 17,50
- Chocolate Shake (350ml) — R$ 16,00
- Jarra de Suco Detox (400ml) — R$ 12,50
- Brownie com Sorvete e Chantilly — R$ 10,00
- Açaí (granola e calda a escolher) — R$ a definir

**🍰 Doces**
- Torta fatia — R$ 13,80
- Torta Especial — R$ 15,00
- Bolo caseiro, fatia (consultar sabores) — R$ 6,00
- Manjar pedaço — R$ 8,00
- Crème Brûlée — R$ 10,80
- Doce de festa fondant, unidade — R$ 4,80
- Chantilly adicional — R$ 3,00
- Adicionais (canela, bule de água, caldas) — R$ 4,00
- Geleias — R$ a definir

**🥪 Salgados**
- Empada (frango, palmito ou queijo) — R$ 10,00
- Empada de Camarão — R$ 12,00
- Croquete de Carne — R$ 15,00
- Bolinho de Bacalhau — R$ 25,00
- Quiche (alho-poró ou carne seca) — R$ 15,00
- Quiche de Bacalhau — R$ 17,00
- Quiche Lorraine — R$ 17,00
- Pastel de Forno — R$ 10,00

**🥖 Sanduíches e Especiais**
- Sanduíche de Pernil — R$ 19,80
- Sanduíche de Carne Seca — R$ 19,80
- Sanduíche de Carne Assada — R$ 19,80
- Misto Quente / Queijo Quente — R$ 12,00
- Pão na Chapa — R$ 5,00
- Pão de Queijo — R$ 8,00

**🍝 Sugestão de Almoço** (servidos individualmente e "montados")
- Lasanha de Berinjela — Bolonhesa com mozarela — R$ 45,00
- Lasanha de Berinjela — Camarão com cottage — R$ 48,00
- Estrogonoff de Frango (batata noisette) — R$ 38,00
- Estrogonoff de Filé Mignon — R$ 45,00
- Estrogonoff de Camarão — R$ 45,00
- Estrogonoff Neblina/gorgonzola (batata noisette) — R$ 54,00
- Fricassê de Bacalhau (batata palha) — R$ 45,00
- Costelinha Suína (barbecue + batata frita) — R$ 42,00
- Escalopinho de Filé Mignon (arroz à montese + noisette) — R$ 48,00

**🥣 Caldos, Sopas e Cremes** (preços a definir)
- Caldo de Mocotó (500ml / 350ml) — R$ a definir
- Caldo Verde (500ml / 350ml) — R$ a definir
- Creme de abóbora com carne seca (500ml / 350ml) — R$ a definir
- Sopa de Legumes (500ml / 350ml) — R$ a definir

**🥛 Bebidas Zero Lactose**
- Macchiato — R$ 13,80
- Café Latte — R$ 13,80
- Cappuccino Mineiro — R$ 13,80
- Chocolate Suíço — R$ 13,80
- Massala Chai — R$ 14,80
- Mocaccino (chocolate ou caramelo) — R$ 13,80
- Milk Shake — R$ 19,80

**🥤 Bebidas**
- Refrigerante lata — R$ 6,00
- Água mineral sem gás — R$ 4,00
- Água mineral com gás — R$ 4,00
- Mate natural — R$ 8,00
- Suco (Vinícola Aurora) — R$ 8,00
- H²O — R$ 8,00
- Suco Del Valle (consultar sabores) — R$ 8,00
- Suco de Laranja Inteiro — R$ 8,00

**🍺 Cervejas**
- Heineken Long Neck (355ml) — R$ 10,00
- Petra Long Neck (355ml) — R$ 10,00
- Eisenbahn Pilsen (355ml) — R$ 10,00
- Budweiser Long Neck (355ml) — R$ 10,00
- Therezópolis (600ml), Eisenbahn Dunkel, Stella Artois (275ml), Corona Extra, Brahma Zero, Malzbier, Baden Baden Especial (600ml) — R$ a definir

**🍷 Vinhos e Espumantes**
- Cabernet Chileno — R$ 31,00
- Cabernet Português — R$ 148,00
- Cabernet Argentino — R$ 148,00

## Entregável
Comece estabelecendo um **design system** coerente (cores, tipografia, botões, cards, espaçamento) e depois aplique-o de forma consistente nas quatro telas. Mostre cada tela em **mobile e desktop**. Capriche no hero e na página de cardápio, que são o coração do site.
