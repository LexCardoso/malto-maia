/* ============================================================
   MALTO MAIA — Painel administrativo
   ============================================================ */

function StatCard({ value, label, accent }) {
  return (
    <div className="card card-pad" style={{ padding: '18px 22px' }}>
      <div style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 30, color: accent || 'var(--espresso-ink)', lineHeight: 1 }}>{value}</div>
      <div style={{ color: 'var(--muted)', fontSize: 13.5, fontWeight: 600, marginTop: 6 }}>{label}</div>
    </div>
  );
}

function Toggle({ on, onChange }) {
  return (
    <button onClick={onChange} role="switch" aria-checked={on}
      style={{ width: 46, height: 27, borderRadius: 999, border: 0, padding: 3, background: on ? 'var(--leaf)' : 'var(--line-strong)', display: 'flex', alignItems: 'center', justifyContent: on ? 'flex-end' : 'flex-start', transition: 'background .18s', cursor: 'pointer', flex: '0 0 auto' }}>
      <span style={{ width: 21, height: 21, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.25)' }} />
    </button>
  );
}

function NewItemModal({ onClose, onAdd }) {
  const { t, lang, menu } = useApp();
  const [form, setForm] = useState({ catId: menu[0].id, name: '', desc: '', price: '', tbd: false });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const inp = { width: '100%', border: '1.5px solid var(--line-strong)', borderRadius: 11, padding: '11px 13px', fontSize: 15, fontFamily: 'var(--body)', background: 'var(--cream-soft)', color: 'var(--espresso)', outline: 'none' };
  const lbl = { fontWeight: 700, fontSize: 13, display: 'block', marginBottom: 6 };
  const submit = () => {
    if (!form.name.trim()) return;
    onAdd(form.catId, {
      name: form.name.trim(),
      desc: { pt: form.desc.trim(), en: form.desc.trim() },
      price: form.tbd || form.price === '' ? null : parseFloat(String(form.price).replace(',', '.')),
    });
    onClose();
  };
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 100, background: 'rgba(42,29,21,0.55)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div onClick={(e) => e.stopPropagation()} className="card rise" style={{ width: 'min(460px, 94vw)', padding: 26, background: 'var(--cream-soft)' }}>
        <h3 className="h-2" style={{ marginBottom: 18 }}>{t('adm.newItem')}</h3>
        <div className="stack" style={{ gap: 14 }}>
          <div>
            <label style={lbl}>{t('adm.col.cat')}</label>
            <select value={form.catId} onChange={(e) => set('catId', e.target.value)} style={inp}>
              {menu.map((c) => <option key={c.id} value={c.id}>{c.name[lang]}</option>)}
            </select>
          </div>
          <div>
            <label style={lbl}>{t('adm.name')}</label>
            <input style={inp} value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Ex.: Bolo de fubá" />
          </div>
          <div>
            <label style={lbl}>{t('adm.desc')}</label>
            <input style={inp} value={form.desc} onChange={(e) => set('desc', e.target.value)} placeholder="Ex.: fatia · com goiabada" />
          </div>
          <div className="row" style={{ gap: 14, alignItems: 'flex-end' }}>
            <div style={{ flex: 1 }}>
              <label style={lbl}>{t('adm.priceField')}</label>
              <input style={{ ...inp, opacity: form.tbd ? 0.4 : 1 }} disabled={form.tbd} value={form.price} onChange={(e) => set('price', e.target.value)} placeholder="0,00" inputMode="decimal" />
            </div>
            <label className="row" style={{ gap: 8, fontSize: 14, fontWeight: 600, paddingBottom: 11, cursor: 'pointer' }}>
              <input type="checkbox" checked={form.tbd} onChange={(e) => set('tbd', e.target.checked)} /> {t('adm.priceTbd')}
            </label>
          </div>
        </div>
        <div className="row" style={{ gap: 10, marginTop: 22, justifyContent: 'flex-end' }}>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>{t('adm.cancel')}</button>
          <button className="btn btn-primary btn-sm" onClick={submit}>{t('adm.add')}</button>
        </div>
      </div>
    </div>
  );
}

function AdminRow({ it, catName }) {
  const { t, lang, toggleAvailable, updateItem, deleteItem } = useApp();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({ name: it.name, desc: it.desc ? it.desc[lang] : '', price: it.price == null ? '' : String(it.price).replace('.', ','), tbd: it.price == null });

  const inp = { border: '1.5px solid var(--line-strong)', borderRadius: 9, padding: '8px 10px', fontSize: 14.5, fontFamily: 'var(--body)', background: 'var(--cream-soft)', color: 'var(--espresso)', outline: 'none', width: '100%' };

  const save = () => {
    updateItem(it.key, {
      name: draft.name.trim() || it.name,
      desc: { pt: draft.desc.trim(), en: draft.desc.trim() },
      price: draft.tbd || draft.price === '' ? null : parseFloat(draft.price.replace(',', '.')),
    });
    setEditing(false);
  };

  if (editing) {
    return (
      <tr style={{ background: 'var(--sun-soft)' }}>
        <td style={{ padding: 10 }}>
          <input style={inp} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
          <input style={{ ...inp, marginTop: 6, fontSize: 13 }} value={draft.desc} onChange={(e) => setDraft({ ...draft, desc: e.target.value })} placeholder={t('adm.desc')} />
        </td>
        <td className="adm-hide-sm" style={{ padding: 10, color: 'var(--muted)', fontSize: 14 }}>{catName}</td>
        <td style={{ padding: 10 }}>
          <input style={{ ...inp, width: 90, opacity: draft.tbd ? 0.4 : 1 }} disabled={draft.tbd} value={draft.price} onChange={(e) => setDraft({ ...draft, price: e.target.value })} placeholder="0,00" inputMode="decimal" />
          <label className="row" style={{ gap: 5, fontSize: 12, marginTop: 5 }}><input type="checkbox" checked={draft.tbd} onChange={(e) => setDraft({ ...draft, tbd: e.target.checked })} /> {t('adm.priceTbd')}</label>
        </td>
        <td className="adm-hide-sm" style={{ padding: 10 }}></td>
        <td style={{ padding: 10 }}>
          <div className="row" style={{ gap: 6, justifyContent: 'flex-end' }}>
            <button className="btn btn-primary btn-sm" style={{ padding: '8px 12px' }} onClick={save}><Ic.check /></button>
            <button className="btn btn-ghost btn-sm" style={{ padding: '8px 12px' }} onClick={() => setEditing(false)}>{t('adm.cancel')}</button>
          </div>
        </td>
      </tr>
    );
  }

  return (
    <tr style={{ opacity: it.available ? 1 : 0.62 }}>
      <td style={{ padding: '13px 10px' }}>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontWeight: 700, fontSize: 15.5, textDecoration: it.available ? 'none' : 'line-through' }}>{it.name}</span>
          {it.signature && <Ic.star style={{ color: 'var(--sun-deep)' }} />}
        </div>
        {it.desc && it.desc[lang] && <div className="adm-hide-sm" style={{ color: 'var(--muted)', fontSize: 13, marginTop: 2 }}>{it.desc[lang]}</div>}
      </td>
      <td className="adm-hide-sm" style={{ padding: '13px 10px', color: 'var(--muted)', fontSize: 14 }}>{catName}</td>
      <td style={{ padding: '13px 10px', fontWeight: 800, color: it.price == null ? 'var(--muted)' : 'var(--terracota)', whiteSpace: 'nowrap' }}>{it.price == null ? t('adm.priceTbd') : fmtBRL(it.price)}</td>
      <td style={{ padding: '13px 10px' }}>
        <div className="row" style={{ gap: 8 }}>
          <Toggle on={it.available} onChange={() => toggleAvailable(it.key)} />
          <span className="adm-hide-sm" style={{ fontSize: 13, fontWeight: 600, color: it.available ? 'var(--leaf)' : 'var(--muted)' }}>{it.available ? t('adm.available') : t('common.unavailable')}</span>
        </div>
      </td>
      <td style={{ padding: '13px 10px' }}>
        <div className="row" style={{ gap: 4, justifyContent: 'flex-end' }}>
          <button onClick={() => setEditing(true)} aria-label="editar" style={{ background: 'var(--cream-deep)', border: '1px solid var(--line-strong)', borderRadius: 9, width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--espresso)' }}><Ic.edit /></button>
          <button onClick={() => deleteItem(it.key)} aria-label="excluir" style={{ background: 'none', border: '1px solid var(--line)', borderRadius: 9, width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)' }}><Ic.trash /></button>
        </div>
      </td>
    </tr>
  );
}

function AdminPage() {
  const { t, lang, menu, updatedDate, markUpdatedToday, addItem } = useApp();
  const [query, setQuery] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [showQR, setShowQR] = useState(false);

  const allItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    const rows = [];
    menu.forEach((cat) => cat.items.forEach((it) => {
      if (!q || it.name.toLowerCase().includes(q) || cat.name[lang].toLowerCase().includes(q)) rows.push({ it, catName: cat.name[lang] });
    }));
    return rows;
  }, [menu, query, lang]);

  const totalItems = menu.reduce((s, c) => s + c.items.length, 0);
  const unavailable = menu.reduce((s, c) => s + c.items.filter((i) => !i.available).length, 0);
  const tbd = menu.reduce((s, c) => s + c.items.filter((i) => i.price == null).length, 0);

  const fmtDate = (d) => new Date(d + 'T00:00:00').toLocaleDateString(lang === 'pt' ? 'pt-BR' : 'en-GB', { day: '2-digit', month: 'long', year: 'numeric' });

  const th = { textAlign: 'left', padding: '12px 10px', fontSize: 12, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--muted)', fontWeight: 800, borderBottom: '2px solid var(--line)' };

  return (
    <main className="section-tight">
      <div className="wrap">
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 20, flexWrap: 'wrap', marginBottom: 24 }}>
          <div>
            <div className="eyebrow-tag" style={{ marginBottom: 8 }}>{t('nav.admin')}</div>
            <h1 className="h-1">{t('adm.title')}</h1>
            <p className="lead" style={{ marginTop: 8, fontSize: 17 }}>{t('adm.sub')}</p>
          </div>
          <div className="card card-pad" style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
            <div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{t('adm.lastUpdate')}</div>
              <div style={{ fontWeight: 700, fontSize: 15.5 }}>{fmtDate(updatedDate)}</div>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={markUpdatedToday}><Ic.check /> {t('adm.markToday')}</button>
          </div>
        </div>

        {/* Stats */}
        <div className="adm-stats" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
          <StatCard value={totalItems} label={t('adm.itemsCount')} />
          <StatCard value={totalItems - unavailable} label={t('adm.available')} accent="var(--leaf)" />
          <StatCard value={unavailable} label={t('common.unavailable')} accent="var(--terracota)" />
          <StatCard value={tbd} label={t('adm.priceTbd')} accent="var(--muted)" />
        </div>

        {/* Toolbar */}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center', marginBottom: 16 }}>
          <div className="row" style={{ gap: 10, flex: 1, minWidth: 220, background: 'var(--cream-soft)', border: '1.5px solid var(--line-strong)', borderRadius: 999, padding: '4px 16px' }}>
            <Ic.search />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('adm.search')}
              style={{ flex: 1, border: 0, background: 'transparent', padding: '10px 0', fontSize: 15.5, fontFamily: 'var(--body)', color: 'var(--espresso)', outline: 'none' }} />
          </div>
          <button className="btn btn-ghost btn-sm" onClick={() => window.print()}><Ic.pdf /> {t('adm.exportPdf')}</button>
          <button className="btn btn-ghost btn-sm" onClick={() => setShowQR(true)}><Ic.qr /> {t('adm.qr')}</button>
          <button className="btn btn-primary btn-sm" onClick={() => setShowNew(true)}><Ic.plus /> {t('adm.add')}</button>
        </div>

        {/* Table */}
        <div className="card" style={{ overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 540 }}>
              <thead>
                <tr>
                  <th style={th}>{t('adm.col.item')}</th>
                  <th className="adm-hide-sm" style={th}>{t('adm.col.cat')}</th>
                  <th style={th}>{t('adm.col.price')}</th>
                  <th style={th}>{t('adm.col.status')}</th>
                  <th style={{ ...th, textAlign: 'right' }}>{t('adm.col.actions')}</th>
                </tr>
              </thead>
              <tbody>
                {allItems.map(({ it, catName }) => <AdminRow key={it.key} it={it} catName={catName} />)}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showNew && <NewItemModal onClose={() => setShowNew(false)} onAdd={addItem} />}
      {showQR && <QRModal onClose={() => setShowQR(false)} />}
    </main>
  );
}
window.AdminPage = AdminPage;
