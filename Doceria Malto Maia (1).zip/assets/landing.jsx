/* ============================================================
   MALTO MAIA — Landing page
   ============================================================ */

function Ph({ label, variant, style, className }) {
  return <div className={cx('ph', variant === 'coffee' && 'ph-coffee', className)} data-label={label} style={style} />;
}
window.Ph = Ph;

function multiline(str) {
  return str.split('\n').map((line, i) => <React.Fragment key={i}>{i > 0 && <br />}{line}</React.Fragment>);
}

/* ---------------- HERO ---------------- */
function Hero() {
  const { t, go } = useApp();
  return (
    <section style={{ position: 'relative', overflow: 'hidden' }}>
      {/* sun glow */}
      <div aria-hidden style={{ position: 'absolute', top: '-220px', right: '-160px', width: 620, height: 620, borderRadius: '50%', background: 'radial-gradient(circle, rgba(245,166,35,0.28), rgba(245,166,35,0) 65%)', pointerEvents: 'none' }} />
      <div className="wrap hero-grid" style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1.05fr 0.95fr', gap: 'clamp(32px, 5vw, 72px)', alignItems: 'center', paddingTop: 'clamp(40px, 7vw, 88px)', paddingBottom: 'clamp(48px, 7vw, 96px)' }}>
        <div className="rise">
          <div className="row" style={{ gap: 10, marginBottom: 22 }}>
            <span className="chip chip-leaf"><Ic.pin /> {t('hero.eyebrow')}</span>
          </div>
          <h1 className="h-display" style={{ marginBottom: 22 }}>{multiline(t('hero.title'))}</h1>
          <p className="lead" style={{ maxWidth: 480, marginBottom: 30 }}>{t('hero.sub')}</p>
          <div className="row row-wrap" style={{ gap: 14, marginBottom: 30 }}>
            <button className="btn btn-primary btn-lg" onClick={() => go('menu')}>{t('cta.menu')} <Ic.arrow /></button>
            <button className="btn btn-ghost btn-lg" onClick={() => go('order')}>{t('cta.order')}</button>
          </div>
          <div className="row" style={{ gap: 12 }}>
            <span className="stars" aria-hidden>★★★★<span style={{ opacity: 0.4 }}>★</span></span>
            <span style={{ fontWeight: 700, fontSize: 14.5 }}>4,4</span>
            <span style={{ color: 'var(--muted)', fontSize: 14.5 }}>· {t('hero.badge')}</span>
          </div>
        </div>

        <div className="rise hero-art" style={{ position: 'relative', animationDelay: '.1s' }}>
          <Ph variant="coffee" label="foto: cappuccino · sol na espuma" style={{ aspectRatio: '4/5', minHeight: 380, borderRadius: 'var(--r-xl)' }} />
          {/* floating sweet card */}
          <div className="card card-pad hero-float" style={{ position: 'absolute', bottom: -26, left: -26, width: 248, padding: 16, boxShadow: '0 24px 50px -22px var(--shadow-deep)' }}>
            <div className="row" style={{ gap: 13 }}>
              <Ph label="" style={{ width: 54, height: 54, minHeight: 0, flex: '0 0 auto', borderRadius: 14 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 17, lineHeight: 1.15, whiteSpace: 'nowrap' }}>Torta de coco</div>
                <div style={{ color: 'var(--terracota)', fontWeight: 800, fontSize: 14, marginTop: 3 }}>{fmtBRL(13.80)}</div>
              </div>
            </div>
          </div>
          {/* logo seal */}
          <div className="hero-hours" style={{ position: 'absolute', top: -22, right: -18, width: 116, height: 116, borderRadius: '50%', background: 'var(--cream)', border: '1px solid var(--line)', boxShadow: '0 18px 40px -20px var(--shadow-deep)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 12 }}>
            <img src="assets/logo-full.png" alt="Malto Maia" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- ABOUT ---------------- */
function About() {
  const { t } = useApp();
  const stats = [
    { n: '+12', l: t('about.stat1') },
    { n: '100%', l: t('about.stat2') },
    { n: '4,4★', l: t('about.stat3') },
  ];
  return (
    <section className="section" style={{ background: 'var(--cream-deep)' }}>
      <div className="wrap about-grid" style={{ display: 'grid', gridTemplateColumns: '0.95fr 1.05fr', gap: 'clamp(32px, 5vw, 72px)', alignItems: 'center' }}>
        <div style={{ position: 'relative' }}>
          <Ph label="foto: salão · casa colonial amarela" style={{ aspectRatio: '5/6', minHeight: 360, borderRadius: 'var(--r-xl)' }} />
          <Ph label="foto: jardim" className="about-second" style={{ position: 'absolute', bottom: -34, right: -28, width: 190, height: 150, minHeight: 0, borderRadius: 'var(--r-lg)', border: '6px solid var(--cream-deep)' }} />
        </div>
        <div>
          <SectionHead eyebrow={t('about.eyebrow')} title={t('about.title')} />
          <div className="stack" style={{ marginTop: 22 }}>
            <p style={{ fontSize: 17.5, lineHeight: 1.7 }}>{t('about.p1')}</p>
            <p style={{ fontSize: 17.5, lineHeight: 1.7, color: 'var(--muted)' }}>{t('about.p2')}</p>
          </div>
          <div className="row" style={{ gap: 0, marginTop: 34, flexWrap: 'wrap' }}>
            {stats.map((s, i) => (
              <div key={i} style={{ paddingRight: 28, marginRight: 28, borderRight: i < 2 ? '1px solid var(--line-strong)' : 'none', marginBottom: 8 }}>
                <div style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 34, color: 'var(--terracota)', lineHeight: 1 }}>{s.n}</div>
                <div style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, marginTop: 6 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- HIGHLIGHTS ---------------- */
function Highlights() {
  const { t, go } = useApp();
  const items = [
    { name: 'Espresso', desc: { pt: '70 ml de café levado a sério', en: '70 ml of coffee, done right' }, price: 6.80, label: 'foto: espresso' },
    { name: 'Torta de Coco', desc: { pt: 'A fatia mais pedida da casa', en: 'The most-ordered slice' }, price: 13.80, label: 'foto: torta de coco', star: true },
    { name: 'Cappuccino Mineiro', desc: { pt: 'Leite, café, chocolate e canela', en: 'Milk, coffee, chocolate & cinnamon' }, price: 10.80, label: 'foto: cappuccino mineiro' },
    { name: 'Pão de Queijo', desc: { pt: 'Quentinho, da roça mineira', en: 'Warm, straight from Minas' }, price: 8.00, label: 'foto: pão de queijo' },
  ];
  const { lang } = useApp();
  return (
    <section className="section">
      <div className="wrap">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24, flexWrap: 'wrap', marginBottom: 'clamp(28px, 4vw, 48px)' }}>
          <SectionHead eyebrow={t('high.eyebrow')} title={t('high.title')} sub={t('high.sub')} />
          <button className="btn btn-ghost" onClick={() => go('menu')}>{t('cta.menu')} <Ic.arrow /></button>
        </div>
        <div className="hl-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'clamp(16px, 2vw, 24px)' }}>
          {items.map((it, i) => (
            <article key={i} className="card hl-card" style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
              <div style={{ position: 'relative' }}>
                <Ph variant="coffee" label={it.label} style={{ borderRadius: 0, aspectRatio: '4/3', minHeight: 0 }} />
                {it.star && <span className="chip chip-sun" style={{ position: 'absolute', top: 12, left: 12 }}><Ic.star /> {t('common.signature')}</span>}
              </div>
              <div className="card-pad" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                <h3 style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 22 }}>{it.name}</h3>
                <p style={{ color: 'var(--muted)', fontSize: 14.5, marginTop: 6, flex: 1 }}>{it.desc[lang]}</p>
                <div style={{ marginTop: 16, fontWeight: 800, color: 'var(--terracota)', fontSize: 18 }}>{fmtBRL(it.price)}</div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- GALLERY ---------------- */
function Gallery() {
  const { t } = useApp();
  const tiles = [
    { label: 'foto: fachada amarela', span: 'tall' },
    { label: 'foto: mesa posta' },
    { label: 'foto: prensa francesa' },
    { label: 'foto: lousa do dia' },
    { label: 'foto: pratos de cerâmica', span: 'wide' },
    { label: 'foto: jardim ao entardecer' },
  ];
  return (
    <section className="section" style={{ background: 'var(--espresso-ink)' }}>
      <div className="wrap">
        <div style={{ color: 'var(--cream)' }}>
          <div className="eyebrow" style={{ marginBottom: 8, color: 'var(--sun)' }}>{t('gal.eyebrow')}</div>
          <h2 className="h-1" style={{ color: 'var(--cream)', maxWidth: 640 }}>{t('gal.title')}</h2>
        </div>
        <div className="gal-grid" style={{ marginTop: 'clamp(28px, 4vw, 44px)', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gridAutoRows: '150px', gap: 14 }}>
          {tiles.map((tile, i) => (
            <Ph key={i} variant="coffee" label={tile.label}
              style={{
                gridColumn: tile.span === 'wide' ? 'span 2' : 'span 1',
                gridRow: tile.span === 'tall' ? 'span 2' : 'span 1',
                minHeight: 0, height: '100%', borderRadius: 'var(--r-lg)',
                border: '1px solid rgba(247,241,230,0.12)',
              }} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- ORDER STRIP ---------------- */
function OrderStrip() {
  const { t, go } = useApp();
  return (
    <section className="section">
      <div className="wrap">
        <div className="order-strip paper-grain" style={{ position: 'relative', overflow: 'hidden', background: 'linear-gradient(135deg, var(--terracota), var(--terracota-d))', borderRadius: 'var(--r-xl)', padding: 'clamp(32px, 5vw, 60px)', color: '#fff', display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 36, alignItems: 'center' }}>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div className="eyebrow" style={{ color: 'var(--sun-soft)', marginBottom: 8 }}>{t('order.eyebrow')}</div>
            <h2 className="h-1" style={{ color: '#fff', maxWidth: 520 }}>{t('order.title')}</h2>
            <p style={{ marginTop: 16, fontSize: 18, color: 'rgba(255,255,255,0.9)', maxWidth: 460 }}>{t('order.sub')}</p>
          </div>
          <div className="row row-wrap" style={{ position: 'relative', zIndex: 1, gap: 14, justifyContent: 'flex-start' }}>
            <button className="btn btn-primary btn-lg" onClick={() => go('order')}>{t('cta.order')} <Ic.arrow /></button>
            <a className="btn btn-lg" href={`https://wa.me/${WA_NUMBER}`} target="_blank" rel="noopener" style={{ background: 'rgba(255,255,255,0.16)', color: '#fff', border: '2px solid rgba(255,255,255,0.4)' }}><Ic.wa /> WhatsApp</a>
          </div>
          <div aria-hidden style={{ position: 'absolute', right: -60, top: -60, width: 280, height: 280, borderRadius: '50%', background: 'rgba(245,166,35,0.25)' }} />
        </div>
      </div>
    </section>
  );
}

/* ---------------- REVIEWS ---------------- */
function Reviews() {
  const { t } = useApp();
  const revs = [
    { txt: t('rev.r1'), who: t('rev.r1a') },
    { txt: t('rev.r2'), who: t('rev.r2a') },
    { txt: t('rev.r3'), who: t('rev.r3a') },
  ];
  return (
    <section className="section" style={{ background: 'var(--cream-deep)' }}>
      <div className="wrap">
        <SectionHead center eyebrow={t('rev.eyebrow')} title={t('rev.title')} />
        <div className="rev-grid" style={{ marginTop: 'clamp(28px, 4vw, 44px)', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'clamp(16px, 2vw, 24px)' }}>
          {revs.map((r, i) => (
            <figure key={i} className="card card-pad" style={{ margin: 0, display: 'flex', flexDirection: 'column', gap: 16 }}>
              <span className="stars">★★★★★</span>
              <blockquote style={{ margin: 0, fontFamily: 'var(--display)', fontStyle: 'italic', fontWeight: 500, fontSize: 20, lineHeight: 1.45, color: 'var(--espresso-ink)' }}>“{r.txt}”</blockquote>
              <figcaption style={{ marginTop: 'auto', fontWeight: 700, fontSize: 14.5, color: 'var(--muted)' }}>{r.who}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- INSTAGRAM ---------------- */
function InstagramRow() {
  const { t } = useApp();
  const labels = ['foto: latte art', 'foto: vitrine de doces', 'foto: mesa no jardim', 'foto: grãos de café', 'foto: fatia de torta', 'foto: detalhe lousa'];
  return (
    <section className="section-tight">
      <div className="wrap">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 16, marginBottom: 26 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>{t('ig.eyebrow')}</div>
            <h2 className="h-2">{t('ig.title')}</h2>
          </div>
          <a className="btn btn-ghost btn-sm" href="https://instagram.com" target="_blank" rel="noopener"><Ic.ig /> {t('ig.follow')}</a>
        </div>
        <div className="ig-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
          {labels.map((l, i) => (
            <div key={i} style={{ position: 'relative' }}>
              <Ph variant="coffee" label="" style={{ aspectRatio: '1', minHeight: 0, borderRadius: 'var(--r-md)' }} />
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(247,241,230,0.85)' }}><Ic.ig /></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- VISIT + HOURS ---------------- */
function Visit() {
  const { t } = useApp();
  const info = [
    { icon: <Ic.pin />, label: t('visit.addr') },
    { icon: <Ic.clock />, label: t('visit.hours') },
    { icon: <Ic.wa />, label: '+55 21 99999-9999' },
  ];
  return (
    <section className="section">
      <div className="wrap visit-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'clamp(28px, 4vw, 56px)', alignItems: 'center' }}>
        <div>
          <SectionHead eyebrow={t('visit.eyebrow')} title={t('visit.title')} />
          <div className="stack" style={{ marginTop: 26 }}>
            {info.map((row, i) => (
              <div key={i} className="row" style={{ gap: 14 }}>
                <span style={{ width: 46, height: 46, flex: '0 0 auto', borderRadius: 14, background: 'var(--sun-soft)', color: 'var(--terracota)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{row.icon}</span>
                <span style={{ fontSize: 17, fontWeight: 600 }}>{row.label}</span>
              </div>
            ))}
          </div>
          <a className="btn btn-solid btn-lg" href="https://maps.google.com/?q=Praia+Seca+Araruama+RJ" target="_blank" rel="noopener" style={{ marginTop: 28 }}>
            <Ic.pin /> {t('cta.directions')}
          </a>
        </div>
        <div style={{ position: 'relative' }}>
          <div className="ph" data-label="mapa: Estrada de Praia Seca, Araruama – RJ" style={{ aspectRatio: '4/3', minHeight: 320, borderRadius: 'var(--r-xl)', background: 'repeating-linear-gradient(0deg, rgba(94,107,79,0.10) 0 22px, transparent 22px 44px), repeating-linear-gradient(90deg, rgba(94,107,79,0.10) 0 22px, transparent 22px 44px), linear-gradient(160deg, #E7E3D2, #DCD7C2)' }}>
          </div>
          <div style={{ position: 'absolute', top: '42%', left: '50%', transform: 'translate(-50%,-50%)', color: 'var(--terracota)' }}>
            <svg viewBox="0 0 24 24" width="48" height="48" fill="var(--terracota)" stroke="#fff" strokeWidth="1.2"><path d="M20 10c0 5.4-8 12-8 12s-8-6.6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="2.6" fill="#fff" stroke="none"/></svg>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- CONCEPT ---------------- */
function Concept() {
  const { t } = useApp();
  return (
    <section className="section" style={{ background: 'var(--leaf)', color: 'var(--cream)' }}>
      <div className="wrap" style={{ maxWidth: 820, textAlign: 'center' }}>
        <div className="eyebrow" style={{ color: 'var(--sun-soft)', marginBottom: 10 }}>{t('concept.eyebrow')}</div>
        <h2 className="h-1" style={{ color: 'var(--cream)' }}>{t('concept.title')}</h2>
        <p style={{ marginTop: 22, fontSize: 'clamp(18px, 2.4vw, 22px)', lineHeight: 1.7, color: 'rgba(247,241,230,0.92)' }}>{t('concept.body')}</p>
      </div>
    </section>
  );
}

/* ---------------- PAGE ---------------- */
function LandingPage() {
  return (
    <main>
      <Hero />
      <About />
      <Highlights />
      <Gallery />
      <OrderStrip />
      <Reviews />
      <InstagramRow />
      <Visit />
      <Concept />
    </main>
  );
}
window.LandingPage = LandingPage;
