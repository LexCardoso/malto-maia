/* ============================================================
   MALTO MAIA — App shell (estado global + roteamento)
   ============================================================ */
const STORE_VERSION = '2';

function buildInitialMenu() {
  return window.MENU_CATEGORIES.map((cat) => ({
    id: cat.id,
    name: cat.name,
    note: cat.note || null,
    items: cat.items.map((it, i) => ({
      key: cat.id + '-' + i,
      name: it.name,
      desc: it.desc || null,
      price: it.price,
      signature: !!it.signature,
      available: true,
    })),
  }));
}

function loadJSON(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; }
}

function App() {
  const [lang, setLangState] = useState(() => loadJSON('mm_lang', 'pt'));
  const [route, setRoute] = useState(() => loadJSON('mm_route', 'home'));
  const [cart, setCart] = useState(() => loadJSON('mm_cart', []));
  const [updatedDate, setUpdatedDate] = useState(() => loadJSON('mm_updated', window.MENU_UPDATED));
  const [menu, setMenu] = useState(() => {
    const saved = loadJSON('mm_menu_v' + STORE_VERSION, null);
    return saved || buildInitialMenu();
  });

  // persist
  useEffect(() => { localStorage.setItem('mm_lang', JSON.stringify(lang)); }, [lang]);
  useEffect(() => { localStorage.setItem('mm_route', JSON.stringify(route)); }, [route]);
  useEffect(() => { localStorage.setItem('mm_cart', JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem('mm_updated', JSON.stringify(updatedDate)); }, [updatedDate]);
  useEffect(() => { localStorage.setItem('mm_menu_v' + STORE_VERSION, JSON.stringify(menu)); }, [menu]);

  const t = (key) => (window.I18N[key] ? window.I18N[key][lang] : key);
  const setLang = (l) => setLangState(l);

  const go = (r) => { setRoute(r); window.scrollTo({ top: 0, behavior: 'auto' }); };

  // ---- menu admin ops ----
  const mutateItem = (key, fn) => setMenu((m) => m.map((cat) => ({
    ...cat, items: cat.items.map((it) => (it.key === key ? fn(it) : it)),
  })));
  const toggleAvailable = (key) => mutateItem(key, (it) => ({ ...it, available: !it.available }));
  const updateItem = (key, patch) => mutateItem(key, (it) => ({ ...it, ...patch }));
  const deleteItem = (key) => setMenu((m) => m.map((cat) => ({ ...cat, items: cat.items.filter((it) => it.key !== key) })));
  const addItem = (catId, item) => setMenu((m) => m.map((cat) => (
    cat.id === catId
      ? { ...cat, items: [...cat.items, { key: catId + '-new-' + Date.now(), signature: false, available: true, ...item }] }
      : cat
  )));
  const markUpdatedToday = () => setUpdatedDate(new Date().toISOString().slice(0, 10));

  // ---- cart ops ----
  const addToCart = (it) => setCart((c) => {
    const found = c.find((x) => x.key === it.key);
    if (found) return c.map((x) => (x.key === it.key ? { ...x, qty: x.qty + 1 } : x));
    return [...c, { key: it.key, name: it.name, price: it.price, qty: 1 }];
  });
  const setQty = (key, qty) => setCart((c) => qty <= 0 ? c.filter((x) => x.key !== key) : c.map((x) => (x.key === key ? { ...x, qty } : x)));
  const removeItem = (key) => setCart((c) => c.filter((x) => x.key !== key));
  const clearCart = () => setCart([]);

  const value = {
    lang, setLang, t, route, go,
    menu, toggleAvailable, updateItem, deleteItem, addItem,
    updatedDate, setUpdatedDate, markUpdatedToday,
    cart, addToCart, setQty, removeItem, clearCart,
  };

  let Page;
  if (route === 'menu') Page = window.MenuPage;
  else if (route === 'order') Page = window.OrderPage;
  else if (route === 'admin') Page = window.AdminPage;
  else Page = window.LandingPage;

  return (
    <AppContext.Provider value={value}>
      <div className="app">
        <Header />
        <Page key={route} />
        <Footer />
      </div>
    </AppContext.Provider>
  );
}
window.App = App;

function mountApp() {
  ReactDOM.createRoot(document.getElementById('root')).render(<App />);
}
if (document.fonts && document.fonts.ready) {
  // avoid first-paint reflow jank: wait for webfonts, but never hang
  Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 1500))]).then(mountApp);
} else {
  mountApp();
}
