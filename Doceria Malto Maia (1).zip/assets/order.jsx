/* ============================================================
   MALTO MAIA — Tela de Encomenda (carrinho + WhatsApp)
   ============================================================ */

function Stepper({ qty, onInc, onDec, small }) {
  const sz = small ? 30 : 36;
  const btn = { width: sz, height: sz, borderRadius: 9, border: '1.5px solid var(--line-strong)', background: 'var(--cream-soft)', color: 'var(--espresso)', display: 'flex', alignItems: 'center', justifyContent: 'center' };
  return (
    <div className="row" style={{ gap: 8 }}>
      <button style={btn} onClick={onDec} aria-label="menos"><Ic.minus /></button>
      <span style={{ minWidth: 22, textAlign: 'center', fontWeight: 800, fontSize: 16 }}>{qty}</span>
      <button style={{ ...btn, background: 'var(--sun-soft)', borderColor: '#ecc879' }} onClick={onInc} aria-label="mais"><Ic.plus /></button>
    </div>
  );
}

function OrderPage() {
  const { t, lang, menu, cart, addToCart, setQty, removeItem, clearCart, go } = useApp();
  const [query, setQuery] = useState('');
  const [notes, setNotes] = useState('');
  const [name, setName] = useState('');
  const [activeCat, setActiveCat] = useState('all');

  const qtyOf = (key) => { const c = cart.find((i) => i.key === key); return c ? c.qty : 0; };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menu
      .filter((cat) => activeCat === 'all' || cat.id === activeCat)
      .map((cat) => ({
        ...cat,
        items: cat.items.filter((it) => it.available && (!q || it.name.toLowerCase().includes(q) || (it.desc && it.desc[lang] && it.desc[lang].toLowerCase().includes(q)))),
      }))
      .filter((cat) => cat.items.length);
  }, [menu, query, activeCat, lang]);

  const total = cart.reduce((s, i) => s + (i.price || 0) * i.qty, 0);
  const hasTbd = cart.some((i) => i.price == null);
  const count = cart.reduce((s, i) => s + i.qty, 0);

  const buildWA = () => {
    const lines = [];
    lines.push('*' + t('ord.waHeader') + '*');
    lines.push('');
    cart.forEach((i) => {
      const price = i.price == null ? t('common.askPrice') : fmtBRL(i.price * i.qty);
      lines.push(`• ${i.qty}x ${i.name} — ${price}`);
    });
    lines.push('');
    lines.push(`*${t('ord.total')}:* ${fmtBRL(total)}${hasTbd ? ' (+ ' + t('common.askPrice') + ')' : ''}`);
    if (notes.trim()) { lines.push(''); lines.push(`*${t('ord.notes')}:* ${notes.trim()}`); }
    if (name.trim()) { lines.push(''); lines.push(`${t('ord.name')}: ${name.trim()}`); }
    return `https://wa.me/${WA_NUMBER}?text=` + encodeURIComponent(lines.join('\n'));
  };

  return (
    <main className="section-tight">
      <div className="wrap">
        {/* Title */}
        <div style={{ marginBottom: 'clamp(24px, 3vw, 36px)' }}>
          <div className="eyebrow" style={{ marginBottom: 6 }}>{t('order.eyebrow')}</div>
          <h1 className="h-display" style={{ fontSize: 'clamp(36px, 6vw, 60px)' }}>{t('ord.title')}</h1>
          <p className="lead" style={{ marginTop: 12, maxWidth: 560 }}>{t('ord.sub')}</p>
        </div>

        <div className="order-grid" style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 'clamp(20px, 3vw, 40px)', alignItems: 'start' }}>
          {/* LEFT: picker */}
          <div>
            <div className="row" style={{ gap: 10, marginBottom: 16, background: 'var(--cream-soft)', border: '1.5px solid var(--line-strong)', borderRadius: 999, padding: '4px 16px' }}>
              <Ic.search />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('ord.search')}
                style={{ flex: 1, border: 0, background: 'transparent', padding: '11px 0', fontSize: 16, fontFamily: 'var(--body)', color: 'var(--espresso)', outline: 'none' }} />
            </div>
            <div className="row" style={{ gap: 8, overflowX: 'auto', paddingBottom: 6, marginBottom: 8 }}>
              {[{ id: 'all', name: { pt: 'Tudo', en: 'All' } }, ...menu].map((cat) => (
                <button key={cat.id} onClick={() => setActiveCat(cat.id)}
                  style={{ whiteSpace: 'nowrap', padding: '7px 14px', borderRadius: 999, border: '1.5px solid', borderColor: activeCat === cat.id ? 'var(--terracota)' : 'var(--line-strong)', background: activeCat === cat.id ? 'var(--terracota)' : 'transparent', color: activeCat === cat.id ? '#fff' : 'var(--muted)', fontWeight: 700, fontSize: 13.5, cursor: 'pointer' }}>
                  {cat.name[lang]}
                </button>
              ))}
            </div>

            {filtered.map((cat) => (
              <div key={cat.id} style={{ marginTop: 18 }}>
                <h3 style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 20, marginBottom: 8, color: 'var(--espresso-ink)' }}>{cat.name[lang]}</h3>
                <div className="stack-sm">
                  {cat.items.map((it) => {
                    const q = qtyOf(it.key);
                    return (
                      <div key={it.key} className="card" style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px' }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 700, fontSize: 16 }}>{it.name}</div>
                          <div style={{ color: 'var(--muted)', fontSize: 13.5, marginTop: 2 }}>
                            {it.price == null ? t('common.askPrice') : fmtBRL(it.price)}{it.desc && it.desc[lang] ? ' · ' + it.desc[lang] : ''}
                          </div>
                        </div>
                        {q > 0
                          ? <Stepper small qty={q} onInc={() => setQty(it.key, q + 1)} onDec={() => setQty(it.key, q - 1)} />
                          : <button className="btn btn-primary btn-sm" onClick={() => addToCart(it)} style={{ padding: '9px 16px' }}><Ic.plus /> {t('ord.add')}</button>}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            {!filtered.length && <p className="text-muted" style={{ padding: '30px 0' }}>—</p>}
          </div>

          {/* RIGHT: summary */}
          <aside className="order-summary" style={{ position: 'sticky', top: 96 }}>
            <div className="card" style={{ overflow: 'hidden' }}>
              <div style={{ background: 'var(--espresso-ink)', color: 'var(--cream)', padding: '18px 22px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 21 }}>{t('ord.summary')}</span>
                <span className="chip" style={{ background: 'var(--sun)', border: 0, color: 'var(--espresso-ink)' }}><Ic.cart /> {count}</span>
              </div>
              <div className="card-pad" style={{ paddingTop: 18, paddingBottom: 18 }}>
                {cart.length === 0 ? (
                  <p style={{ color: 'var(--muted)', fontSize: 15, padding: '20px 0', textAlign: 'center' }}>{t('ord.empty')}</p>
                ) : (
                  <div className="stack-sm" style={{ marginBottom: 8 }}>
                    {cart.map((i) => (
                      <div key={i.key} className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 700, fontSize: 15 }}>{i.name}</div>
                          <div style={{ color: 'var(--terracota)', fontWeight: 700, fontSize: 13.5 }}>{i.price == null ? t('common.askPrice') : fmtBRL(i.price)}</div>
                        </div>
                        <Stepper small qty={i.qty} onInc={() => setQty(i.key, i.qty + 1)} onDec={() => setQty(i.key, i.qty - 1)} />
                        <button onClick={() => removeItem(i.key)} aria-label="remover" style={{ background: 'none', border: 0, color: 'var(--muted)', padding: 6, marginTop: 3 }}><Ic.trash /></button>
                      </div>
                    ))}
                  </div>
                )}

                <hr className="divider-rule" style={{ margin: '14px 0' }} />
                <label style={{ fontWeight: 700, fontSize: 13.5, display: 'block', marginBottom: 6 }}>{t('ord.name')}</label>
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t('ord.namePh')}
                  style={{ width: '100%', border: '1.5px solid var(--line-strong)', borderRadius: 12, padding: '11px 14px', fontSize: 15, fontFamily: 'var(--body)', background: 'var(--cream-soft)', color: 'var(--espresso)', marginBottom: 14, outline: 'none' }} />
                <label style={{ fontWeight: 700, fontSize: 13.5, display: 'block', marginBottom: 6 }}>{t('ord.notes')}</label>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder={t('ord.notesPh')} rows={3}
                  style={{ width: '100%', border: '1.5px solid var(--line-strong)', borderRadius: 12, padding: '11px 14px', fontSize: 15, fontFamily: 'var(--body)', background: 'var(--cream-soft)', color: 'var(--espresso)', resize: 'vertical', outline: 'none' }} />

                <div className="row" style={{ justifyContent: 'space-between', marginTop: 18, marginBottom: 4 }}>
                  <span style={{ fontWeight: 700, fontSize: 15 }}>{t('ord.total')}</span>
                  <span style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 26, color: 'var(--terracota)' }}>{fmtBRL(total)}{hasTbd && <span style={{ fontSize: 14, color: 'var(--muted)' }}> +</span>}</span>
                </div>
                <p className="text-muted" style={{ fontSize: 12.5, marginBottom: 16 }}>{t('ord.totalNote')}</p>

                <a className={cx('btn btn-wa btn-block btn-lg')} href={cart.length ? buildWA() : undefined} target="_blank" rel="noopener"
                  style={{ pointerEvents: cart.length ? 'auto' : 'none', opacity: cart.length ? 1 : 0.5 }}>
                  <Ic.wa /> {t('ord.send')}
                </a>
                {cart.length > 0 && (
                  <button className="btn btn-ghost btn-block btn-sm" style={{ marginTop: 10 }} onClick={clearCart}>{t('ord.clear')}</button>
                )}
              </div>
            </div>
            <p className="text-muted" style={{ fontSize: 13, marginTop: 14, textAlign: 'center' }}>
              {t('visit.hours')}
            </p>
          </aside>
        </div>
      </div>
    </main>
  );
}
window.OrderPage = OrderPage;
