/* ============================================================
   MALTO MAIA — Página de Cardápio
   ============================================================ */

function QRModal({ onClose }) {
  const { t } = useApp();
  const url = 'https://maltomaia.com.br/cardapio';
  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=0&color=3B2A20&bgcolor=FBF7EF&data=${encodeURIComponent(url)}`;
  const [err, setErr] = useState(false);
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 100, background: 'rgba(42,29,21,0.55)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div onClick={(e) => e.stopPropagation()} className="card rise" style={{ width: 'min(380px, 92vw)', padding: 28, textAlign: 'center', background: 'var(--cream-soft)' }}>
        <div className="eyebrow" style={{ marginBottom: 4 }}>{t('menu.qrTitle')}</div>
        <h3 className="h-2" style={{ marginBottom: 18 }}>Malto Maia</h3>
        <div style={{ width: 240, height: 240, margin: '0 auto', borderRadius: 18, border: '1px solid var(--line)', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', padding: 12 }}>
          {err
            ? <div className="ph" data-label="QR Code" style={{ width: '100%', height: '100%' }} />
            : <img src={qrSrc} alt="QR Code do cardápio" width="216" height="216" onError={() => setErr(true)} />}
        </div>
        <p style={{ marginTop: 16, color: 'var(--muted)', fontSize: 14.5 }}>{t('menu.qrHint')}</p>
        <code style={{ display: 'block', marginTop: 10, fontSize: 12.5, color: 'var(--terracota)' }}>{url}</code>
        <button className="btn btn-ghost btn-block" style={{ marginTop: 18 }} onClick={onClose}>{t('menu.close')}</button>
      </div>
    </div>
  );
}
window.QRModal = QRModal;

function MenuItemRow({ it }) {
  const { t, lang } = useApp();
  const dim = !it.available;
  return (
    <div className="menu-row" style={{ display: 'flex', alignItems: 'baseline', gap: 12, padding: '15px 0', borderBottom: '1px solid var(--line)', opacity: dim ? 0.55 : 1 }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="row" style={{ gap: 9, flexWrap: 'wrap' }}>
          <span style={{ fontFamily: 'var(--display)', fontWeight: 600, fontSize: 19, color: 'var(--espresso-ink)', textDecoration: dim ? 'line-through' : 'none' }}>{it.name}</span>
          {it.signature && <span className="chip chip-sun" style={{ padding: '3px 9px', fontSize: 11.5 }}><Ic.star /> {t('common.signature')}</span>}
          {dim && <span className="chip" style={{ padding: '3px 9px', fontSize: 11.5, background: 'var(--cream-deep)', color: 'var(--muted)' }}>{t('common.unavailable')}</span>}
        </div>
        {it.desc && it.desc[lang] && <div style={{ color: 'var(--muted)', fontSize: 14, marginTop: 3 }}>{it.desc[lang]}</div>}
      </div>
      <div className="menu-leader" />
      <div style={{ flex: '0 0 auto', fontWeight: 800, fontSize: 17, color: it.price == null ? 'var(--muted)' : 'var(--terracota)', whiteSpace: 'nowrap' }}>
        {it.price == null ? t('common.askPrice') : fmtBRL(it.price)}
      </div>
    </div>
  );
}

function CategoryBlock({ cat, refCb }) {
  const { lang } = useApp();
  return (
    <section ref={refCb} id={'cat-' + cat.id} style={{ scrollMarginTop: 140, marginBottom: 'clamp(36px, 5vw, 56px)' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap', borderBottom: '2px solid var(--espresso-ink)', paddingBottom: 12, marginBottom: 6 }}>
        <h2 style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 'clamp(26px, 3.4vw, 34px)' }}>{cat.name[lang]}</h2>
        {cat.note && cat.note[lang] && <span style={{ fontFamily: 'var(--script)', fontSize: 21, color: 'var(--terracota)' }}>{cat.note[lang]}</span>}
      </div>
      <div className="menu-cols" style={{ columnGap: 56 }}>
        {cat.items.map((it) => <MenuItemRow key={it.key} it={it} />)}
      </div>
    </section>
  );
}

function MenuPage() {
  const { t, lang, menu, updatedDate } = useApp();
  const [showQR, setShowQR] = useState(false);
  const [active, setActive] = useState(menu[0] && menu[0].id);
  const refs = useRef({});

  const scrollToCat = (id) => {
    const el = refs.current[id];
    if (!el) return;
    const top = el.getBoundingClientRect().top + window.scrollY - 120;
    window.scrollTo({ top, behavior: 'smooth' });
  };

  useEffect(() => {
    const onScroll = () => {
      let cur = menu[0] && menu[0].id;
      for (const cat of menu) {
        const el = refs.current[cat.id];
        if (el && el.getBoundingClientRect().top - 160 <= 0) cur = cat.id;
      }
      setActive(cur);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, [menu]);

  const fmtDate = (d) => {
    const dt = new Date(d + 'T00:00:00');
    return dt.toLocaleDateString(lang === 'pt' ? 'pt-BR' : 'en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
  };

  return (
    <main className="menu-page">
      {/* Header band */}
      <div className="no-print" style={{ background: 'var(--cream-deep)', borderBottom: '1px solid var(--line)' }}>
        <div className="wrap" style={{ paddingTop: 'clamp(32px, 5vw, 56px)', paddingBottom: 'clamp(24px, 3vw, 36px)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 20, flexWrap: 'wrap' }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 6 }}>{t('hero.eyebrow')}</div>
              <h1 className="h-display" style={{ fontSize: 'clamp(40px, 7vw, 68px)' }}>{t('menu.title')}</h1>
              <p className="lead" style={{ marginTop: 12, maxWidth: 520 }}>{t('menu.sub')}</p>
              <div className="row" style={{ gap: 8, marginTop: 14, color: 'var(--muted)', fontSize: 14 }}>
                <Ic.clock /> <span>{t('common.updated')} <strong style={{ color: 'var(--espresso-ink)' }}>{fmtDate(updatedDate)}</strong></span>
              </div>
            </div>
            <div className="row row-wrap" style={{ gap: 12 }}>
              <button className="btn btn-ghost" onClick={() => window.print()}><Ic.pdf /> {t('menu.exportPdf')}</button>
              <button className="btn btn-solid" onClick={() => setShowQR(true)}><Ic.qr /> {t('menu.qr')}</button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky quick-nav */}
      <div className="no-print menu-quicknav" style={{ position: 'sticky', top: 78, zIndex: 30, background: 'rgba(247,241,230,0.94)', backdropFilter: 'blur(10px)', borderBottom: '1px solid var(--line)' }}>
        <div className="wrap" style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingTop: 12, paddingBottom: 12 }}>
          {menu.map((cat) => (
            <button key={cat.id} onClick={() => scrollToCat(cat.id)}
              style={{
                whiteSpace: 'nowrap', padding: '8px 15px', borderRadius: 999, border: '1.5px solid',
                borderColor: active === cat.id ? 'var(--espresso-ink)' : 'var(--line-strong)',
                background: active === cat.id ? 'var(--espresso-ink)' : 'transparent',
                color: active === cat.id ? 'var(--cream)' : 'var(--muted)',
                fontWeight: 700, fontSize: 14, cursor: 'pointer', transition: 'all .15s',
              }}>
              {cat.name[lang]}
            </button>
          ))}
        </div>
      </div>

      {/* Print header (only on print) */}
      <div className="print-only print-head">
        <div style={{ fontFamily: 'var(--display)', fontWeight: 700, fontSize: 28 }}>Malto Maia · Cardápio</div>
        <div style={{ fontSize: 12 }}>Estrada de Praia Seca, Araruama – RJ · {t('common.updated')} {fmtDate(updatedDate)}</div>
      </div>

      {/* Categories */}
      <div className="wrap section-tight">
        {menu.map((cat) => (
          <CategoryBlock key={cat.id} cat={cat} refCb={(el) => (refs.current[cat.id] = el)} />
        ))}
        <p className="text-muted no-print" style={{ fontSize: 13.5, marginTop: 8 }}>* {t('ord.totalNote')}</p>
      </div>

      {showQR && <QRModal onClose={() => setShowQR(false)} />}
    </main>
  );
}
window.MenuPage = MenuPage;
